#ifndef COMIO
#define COMIO
#include <Chassis.h>
const float wheelPeremeter = 7 * PI;
const int encoderTickPerSecond = 1440;
const float carRadius = 7.62;
#endif 